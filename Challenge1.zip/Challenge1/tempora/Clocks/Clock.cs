using System;

namespace Tempora.Clocks
{
    /// <summary>
    /// Represents a clock with a specific time.
    /// </summary>
    public class Clock
    {
        /// <summary>
        /// Gets the time of the clock in HH:mm format.
        /// </summary>
        public string Time { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Clock"/> class with the specified time.
        /// </summary>
        /// <param name="time">The time in HH:mm format.</param>
        /// <exception cref="ArgumentException">Thrown when the time format is invalid.</exception>
        public Clock(string time)
        {
            if (!IsValidTimeFormat(time))
            {
                throw new ArgumentException("Invalid time format. Expected format is HH:mm.", nameof(time));
            }

            Time = time;
        }

        /// <summary>
        /// Gets the total minutes from 00:00 for the clock's time.
        /// </summary>
        /// <returns>The total minutes from 00:00.</returns>
        public int GetTotalMinutes()
        {
            var timeParts = Time.Split(':');
            int hours = int.Parse(timeParts[0]);
            int minutes = int.Parse(timeParts[1]);
            return (hours * 60) + minutes;
        }

        /// <summary>
        /// Validates the time format.
        /// </summary>
        /// <param name="time">The time string to validate.</param>
        /// <returns>True if the time format is valid; otherwise, false.</returns>
        private bool IsValidTimeFormat(string time)
        {
            return TimeSpan.TryParseExact(time, "hh\\:mm", null, out _);
        }
    }
}