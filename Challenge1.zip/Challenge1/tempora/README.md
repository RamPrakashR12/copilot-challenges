# Tempora Clock Synchronization Project

## Overview
The Tempora project is designed to synchronize various clocks in the mechanical town of Tempora with the Grand Clock Tower. The application checks the time of each clock and calculates how many minutes each clock is ahead or behind the Grand Clock Tower, which is set to 15:00.

## Project Structure
The project consists of the following files and directories:

- **Program.cs**: Entry point of the application that initializes the clock synchronization service and outputs time differences.
- **Clocks/Clock.cs**: Defines the `Clock` class representing a clock with a time property and methods for time calculations.
- **Services/ClockSynchronizationService.cs**: Contains the `ClockSynchronizationService` class responsible for synchronizing clocks and calculating time differences.
- **Models/TimeDifference.cs**: Defines the `TimeDifference` class for encapsulating time difference data.
- **Properties/AssemblyInfo.cs**: Contains assembly-level attributes for project metadata.
- **tempora.csproj**: Project file with configuration settings for the .NET application.

## How to Run
1. Ensure you have the .NET SDK installed on your machine.
2. Clone the repository or download the project files.
3. Navigate to the project directory in your terminal.
4. Run the application using the command:
   ```
   dotnet run
   ```

## Future Enhancements
- Implement a visual representation of the clocks.
- Add functionality to allow users to set their own clock times.
- Improve the user interface for better interaction.

## License
This project is licensed under the MIT License. See the LICENSE file for more details.