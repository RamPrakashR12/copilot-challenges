// This file contains assembly-level attributes for the project.

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Tempora")]
[assembly: AssemblyDescription("A clock synchronization application for the town of Tempora.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Your Company Name")]
[assembly: AssemblyProduct("Tempora Clock Synchronization System")]
[assembly: AssemblyCopyright("Copyright © Your Company Name")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("d1e8f3b2-4c5e-4b7c-8c5e-1f3e8b5c7e8f")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]