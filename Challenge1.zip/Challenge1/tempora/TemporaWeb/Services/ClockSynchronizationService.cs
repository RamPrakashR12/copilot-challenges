using System;
using System.Collections.Generic;
using System.Linq;
using Tempora.Clocks;

namespace TemporaWeb.Services
{
    /// <summary>
    /// Provides services for synchronizing clocks and calculating time differences.
    /// </summary>
    public class ClockSynchronizationService
    {
        private const int GrandClockHour = 15;
        private const int GrandClockMinute = 0;

        /// <summary>
        /// Gets the time differences in minutes from the Grand Clock Tower (15:00).
        /// </summary>
        /// <param name="clocks">The list of clocks to compare.</param>
        /// <returns>An array of time differences in minutes.</returns>
        /// <exception cref="ArgumentNullException">Thrown when the clocks list is null.</exception>
        /// <exception cref="ArgumentException">Thrown when the clocks list is empty.</exception>
        public int[] GetTimeDifferences(List<Clock> clocks)
        {
            if (clocks == null)
            {
                throw new ArgumentNullException(nameof(clocks), "The clocks list cannot be null.");
            }

            if (!clocks.Any())
            {
                throw new ArgumentException("The clocks list cannot be empty.", nameof(clocks));
            }

            int grandClockTotalMinutes = (GrandClockHour * 60) + GrandClockMinute;
            return clocks.Select(clock => clock.GetTotalMinutes() - grandClockTotalMinutes).ToArray();
        }
    }
}