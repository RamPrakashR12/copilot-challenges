using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using Tempora.Clocks;
using TemporaWeb.Controllers;
using TemporaWeb.Services;
using Xunit;

namespace TemporaWeb.Tests.Controllers
{
    public class ClockControllerTest
    {
        [Fact]
        public void Index_ReturnsViewResult_WithCorrectModel()
        {
            // Arrange
            var controller = new ClockController();

            // Act
            var result = controller.Index() as ViewResult;

            // Assert
            Assert.NotNull(result);
            Assert.NotNull(result.ViewData["Clocks"]);
            Assert.NotNull(result.ViewData["TimeDifferences"]);

            var clocks = result.ViewData["Clocks"] as List<Clock>;
            var timeDifferences = result.ViewData["TimeDifferences"] as int[];

            Assert.Equal(4, clocks.Count);
            Assert.Equal("14:45", clocks[0].Time);
            Assert.Equal("15:05", clocks[1].Time);
            Assert.Equal("15:00", clocks[2].Time);
            Assert.Equal("14:40", clocks[3].Time);

            Assert.Equal(4, timeDifferences.Length);
            Assert.Equal(-15, timeDifferences[0]);
            Assert.Equal(5, timeDifferences[1]);
            Assert.Equal(0, timeDifferences[2]);
            Assert.Equal(-20, timeDifferences[3]);
        }
    }
}