using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using Tempora.Clocks;
using TemporaWeb.Services;

namespace TemporaWeb.Controllers
{
    public class ClockController : Controller
    {
        private readonly ClockSynchronizationService _synchronizationService;

        public ClockController()
        {
            _synchronizationService = new ClockSynchronizationService();
        }

        public IActionResult Index()
        {
            // Create a list of clocks with their respective times
            List<Clock> clocks = new List<Clock>
            {
                new Clock("14:45"),
                new Clock("15:05"),
                new Clock("15:00"),
                new Clock("14:40")
            };

            // Get the time differences
            int[] timeDifferences = _synchronizationService.GetTimeDifferences(clocks);

            // Pass the clocks and time differences to the view
            ViewBag.Clocks = clocks;
            ViewBag.TimeDifferences = timeDifferences;

            return View();
        }
    }
}