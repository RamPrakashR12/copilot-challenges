using System;
using System.Collections.Generic;
using Tempora.Clocks;
using Tempora.Services;

namespace Tempora
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize the ClockSynchronizationService
            ClockSynchronizationService synchronizationService = new ClockSynchronizationService();

            // Create a list of clocks with their respective times
            List<Clock> clocks = new List<Clock>
            {
                new Clock("14:45"),
                new Clock("15:05"),
                new Clock("15:00"),
                new Clock("14:40")
            };

            // Get the time differences
            int[] timeDifferences = synchronizationService.GetTimeDifferences(clocks);

            // Output the time differences
            Console.WriteLine("Time differences in minutes from the Grand Clock Tower (15:00):");
            for (int i = 0; i < clocks.Count; i++)
            {
                Console.WriteLine($"Clock {i + 1}: {timeDifferences[i]} minutes");
            }

            // Display the clocks
            DisplayClocks(clocks);
        }

        static void DisplayClocks(List<Clock> clocks)
        {
            Console.WriteLine("\nGrand Clock Tower (15:00)");
            DisplayClock("15:00");

            for (int i = 0; i < clocks.Count; i++)
            {
                Console.WriteLine($"\nClock {i + 1} ({clocks[i].Time})");
                DisplayClock(clocks[i].Time);
            }
        }

        static void DisplayClock(string time)
        {
            string[] timeParts = time.Split(':');
            int hours = int.Parse(timeParts[0]);
            int minutes = int.Parse(timeParts[1]);

            Console.WriteLine("  _______");
            Console.WriteLine(" /       \\");
            Console.WriteLine("|  " + time + "  |");
            Console.WriteLine(" \\_______/");
            Console.WriteLine("     |");
            Console.WriteLine("     |");
            Console.WriteLine("     O");

            // Display hour hand
            DisplayHand(hours % 12, 12, "Hour");

            // Display minute hand
            DisplayHand(minutes, 60, "Minute");
        }

        static void DisplayHand(int value, int maxValue, string handType)
        {
            double angle = (double)value / maxValue * 360;
            Console.WriteLine($"{handType} hand angle: {angle} degrees");
        }
    }
}