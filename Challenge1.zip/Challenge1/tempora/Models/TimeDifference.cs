public class TimeDifference
{
    public int DifferenceInMinutes { get; set; }

    public TimeDifference(int differenceInMinutes)
    {
        DifferenceInMinutes = differenceInMinutes;
    }
}